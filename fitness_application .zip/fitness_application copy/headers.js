module.exports = {
  headers: [
    {
      source: '/:path*',
      headers: [
        {
          key: 'Permissions-Policy',
          value: 'camera=self'
        }
      ]
    }
  ]
} 